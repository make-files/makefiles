package go1

// Global is a variable that is used in the tests.
var Global *TestMessage
